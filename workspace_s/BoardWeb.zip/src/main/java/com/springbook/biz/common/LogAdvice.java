package com.springbook.biz.common;

public class LogAdvice {
	
	public void printLog() {
		System.out.println("[공통 로그] 비지니스 로직 수행 전 동작");
	}

}
